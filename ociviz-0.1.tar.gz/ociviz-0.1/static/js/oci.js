var express = require('express');
var app = express();
var fs = require("fs");
var http = require("http")
var https = require("https")
var request = require('request');
var os = require('os');
var httpSignature = require('http-signature');
var jsSHA = require("jssha");


var identityDomain = "identity.eu-frankfurt-1.oraclecloud.com";
var coreServicesDomain = "iaas.eu-frankfurt-1.oraclecloud.com";
var dbServicesDomain = "database.eu-frankfurt-1.oraclecloud.com";




// signing function as described at https://docs.us-phoenix-1.oraclecloud.com/Content/API/Concepts/signingrequests.htm
function  sign(request, options) {

    var apiKeyId = options.tenancyId + "/" + options.userId + "/" + options.keyFingerprint;

    var headersToSign = [
        "host",
        "date",
        "(request-target)"
    ];

    var methodsThatRequireExtraHeaders = ["POST", "PUT"];

    if(methodsThatRequireExtraHeaders.indexOf(request.method.toUpperCase()) !== -1) {
        options.body = options.body || "";

        var shaObj = new jsSHA("SHA-256", "TEXT");
        shaObj.update(options.body);

        request.setHeader("Content-Length", options.body.length);
        request.setHeader("x-content-sha256", shaObj.getHash('B64'));

        headersToSign = headersToSign.concat([
            "content-type",
            "content-length",
            "x-content-sha256"
        ]);
    }

    httpSignature.sign(request, {
        key: options.privateKey,
		passphrase: options.passPhrase,
        keyId: apiKeyId,
        headers: headersToSign
    });

    var newAuthHeaderValue = request.getHeader("Authorization").replace("Signature ", "Signature version=\"1\",");
    request.setHeader("Authorization", newAuthHeaderValue);	
}




// gets the list of Compartments  in a tenancy
function getCompartments   (config, callback) {
//        path: "/20160918/compartments/" + encodeURIComponent(config['tenancy']),

    var options = {
        host: identityDomain,
        path: "/20160918/compartments?compartmentId=" + config['tenancy'] ,
    };

    var request = https.request(options, handleRequest(callback));

	signRequest(request, config);


    request.end();
};

// gets a given compartment
 function getCompartment  (config, compId, callback) {
    var options = {
        host: identityDomain,
        path: "/20160918/compartments/" + encodeURIComponent(compId) ,
    };

    var request = https.request(options, handleRequest(callback));

	signRequest(request, config);


    request.end();
};

// gets the list of VCNs 
function getVcns (config, compId, callback) {
//        path: "/20160918/vcns?compartmentId=" + encodeURIComponent(compId),

    var options = {
        host: coreServicesDomain,
        path: "/20160918/vcns?compartmentId=" + encodeURIComponent(compId),
    };

    var request = https.request(options, handleRequest(callback));

 	signRequest(request, config);


    request.end();
};


 function getLoadBalancers(config, compId, callback) {
    var options = {
        host: coreServicesDomain,
        path: "/20170115/loadBalancers?compartmentId=" + encodeURIComponent(compId),
    };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};




 function getDbSystems  (config, compId, callback) {
    var options = {
        host: dbServicesDomain,
        path: "/20160918/dbSystems?compartmentId=" + encodeURIComponent(compId),
    };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};


 function getAds  (config, callback) {
    var options = {
        host: identityDomain,
        path: "/20160918/availabilityDomains?compartmentId=" + config['tenancy'] ,
    };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};


 function getInstances(config, compId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/instances?compartmentId=" + encodeURIComponent(compId),
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};

 function getInstance (config, instanceId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/instances/" + encodeURIComponent(instanceId),
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};

 function getVnicAttachments(config, compId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/vnicAttachments?compartmentId=" + encodeURIComponent(compId),
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};


 function getInternetGateways(config, compId, vcnId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/internetGateways?compartmentId=" + encodeURIComponent(compId) + "&vcnId=" + encodeURIComponent(vcnId),
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};


 function getRouteTables(config, compId, vcnId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/routeTables?compartmentId=" + encodeURIComponent(compId) + "&vcnId=" + encodeURIComponent(vcnId),
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};

 function getSubnets(config, compId, vcnId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/subnets?compartmentId=" + encodeURIComponent(compId) + "&vcnId=" + encodeURIComponent(vcnId),
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};


 function getSubnet(config, subnetId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/subnets/" + encodeURIComponent(subnetId) ,
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};
 

 function getPrivateIps(config, subnetId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/privateIps?subnetId=" + encodeURIComponent(subnetId) ,
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};
 
 
 function getDrgs(config, compId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/drgs?compartmentId=" + encodeURIComponent(compId) ,
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};


 function getDrg(config, drgId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/drgs/" + encodeURIComponent(drgId) ,
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};



function  getSecurityLists  (config, compId, vcnId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/securityLists?compartmentId=" + encodeURIComponent(compId) + "&vcnId=" +  encodeURIComponent(vcnId) ,
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};


 function getSecurityList(config, securityListId, callback) {
    var options = {
         host: coreServicesDomain,
        path: "/20160918/securityLists/" + encodeURIComponent(securityListId) ,
   };

    var request = https.request(options, handleRequest(callback));
	signRequest(request, config);

    request.end();
};



 function signRequest(request, config){
	    sign(request, {
        privateKey: config['privateKey'],
        keyFingerprint: config['fingerprint'],
        tenancyId: config['tenancy'],
        userId: config['user'],
		passPhrase: config['pass_phrase']
    });

}

// generates a function to handle the https.request response object
function  handleRequest(callback) {

    return function(response) {
        var responseBody = "";

        response.on('data', function(chunk) {
        responseBody += chunk;
    });

        response.on('end', function() {
            callback(JSON.parse(responseBody));
        });
    }
}




module.exports = {	
getConfig: function (configPath, section){
	var sections = {};
	try {
		if(configPath.indexOf("~/") === 0) {
			configPath = configPath.replace("~", os.homedir())
		}	
		sectionName = "";
		props = {};
		var lines = require('fs').readFileSync(configPath, 'utf-8')
		.split('\n')
		.filter(Boolean);


		for (var i=0; i< lines.length; i++){
			var line = lines[i];
			if (line.startsWith('[') ){
				if (sectionName != "")
					sections[sectionName] = props;
				sectionName = line.replace('[','').replace(']','').replace ('\r','');
				props ={};	
				
			}
			else {
				var a = line.split('=');
				props[a[0]] = a[1].replace('\r','');
			}
		}


  	    sections[sectionName] = props;
		var rsec = sections[section];
		var privateKeyPath = rsec['key_file'];
		if(privateKeyPath.indexOf("~/") === 0) {
			privateKeyPath = privateKeyPath.replace("~", os.homedir())
		}
		 
 		rsec['privateKey'] = fs.readFileSync(privateKeyPath, 'ascii');
		return (rsec);

	} catch (error){
		throw (error)
	}

},

get_compartment: function(config, compId){
	return new Promise(function (resolve, reject) {	
	try{
		getCompartment(config, compId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

 list_compartments: function(config){
	return new Promise(function (resolve, reject) {	
	try{
		getCompartments(config, function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},


 list_vcns: function(config, compartmentId){
	return new Promise(function (resolve, reject) {	
	try{
		getVcns(config,compartmentId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

 list_load_balancers: function(config, compartmentId){
	return new Promise(function (resolve, reject) {	
	try{
		getVcns(config,compartmentId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},
 list_db_systems: function(config, compartmentId){
	return new Promise(function (resolve, reject) {	
	try{
		getDbSystems(config,compartmentId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

list_availability_domains: function(config){
	return new Promise(function (resolve, reject) {	
	try{
		getAds(config,   function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

 list_instances: function (config, compId){
	return new Promise(function (resolve, reject) {	
	try{
		getInstances(config, compId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

 get_instance: function (config, instanceId){
	return new Promise(function (resolve, reject) {	
	try{
		getInstance(config, instanceId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},


 list_vnic_attachments: function (config,  compId){
	return new Promise(function (resolve, reject) {	
	try{
		getVnicAttachments(config, compId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},


 list_internet_gateways: function(config,  compId, vcnId){
	return new Promise(function (resolve, reject) {	
	try{
		getInternetGateways(config, compId, vcnId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},
 list_route_tables: function(config,  compId, vcnId){
	return new Promise(function (resolve, reject) {	
	try{
		getRouteTables(config, compId, vcnId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

 list_subnets: function(config,  compId, vcnId){
	return new Promise(function (resolve, reject) {	
	try{
		getSubnets(config, compId, vcnId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},


 get_subnet: function(config,  subnetId){
	return new Promise(function (resolve, reject) {	
	try{
		getSubnet(config, subnetId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

list_private_ips: function (config,  subnetId){
	return new Promise(function (resolve, reject) {	
		try{
		getPrivateIps(config, subnetId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

list_drgs: function (config,  compId){
	return new Promise(function (resolve, reject) {	
		try{
		getDrgs(config, compId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

 get_drg:  function (config,  drgId){
	return new Promise(function (resolve, reject) {	
		try{
		getDrg(config, drgId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

list_security_lists: function(config,  compId, vcnId){
	return new Promise(function (resolve, reject) {	
		try{
		getSecurityLists(config, compId, vcnId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
},

 get_security_list: function(config,  securityListId){
	return new Promise(function (resolve, reject) {	
		try{
		getSecurityList(config, securityListId,  function(data) {
			resolve(data);
		})
	}
	catch (error){
		reject(error);
	}
	});
}
};