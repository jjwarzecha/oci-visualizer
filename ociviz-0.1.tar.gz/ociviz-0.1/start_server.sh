SET FLASK_APP=ocivizserver.py
export FLASK_APP
flask run --port 8000