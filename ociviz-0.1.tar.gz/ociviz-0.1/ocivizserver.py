"""
---------------------------------------------------------------------------
	___  ____     _    ____ _     _____
    / _ \|  _ \   / \  / ___| |   | ____|
   | | | | |_) | / _ \| |   | |   |  _|
   | |_| |  _ < / ___ | |___| |___| |___
    \___/|_| \_/_/   \_\____|_____|_____|   OCI Visualization Tool

 
Author Michel Benoliel
Oracle 
---------------------------------------------------------------------------

"""


from flask import Flask
from flask_cors import CORS
from flask import request
from  ociviz import generateGraphFile
import argparse
import json
import oci
from oci.exceptions import ProfileNotFound
from oci.config import from_file
from oci.core import ComputeClient

from os.path import expanduser
import os



app = Flask(__name__)

# oci visualizer extract service. extract all information required to visualize a compartment
@app.route('/visualize_compartment')
def ocivizcn():
	args = request.args
	argList = []
	for arg in args:
		argList.append ("--" + arg)
		argList.append (args[arg])
	myresponse = generateGraphFile(argList)
	return myresponse 
	
	
# list compartments for a given config  profile
@app.route('/list_compartments/<profile>')
def getCompartments(profile):
	
	args = parseArgs(request.args)
	
	response = []
	if args['mode'] == "OFFLINE":
		responseFile = open("static/network.json",'r')
		data = responseFile.read()
		alldata = json.loads(data)
		for v in alldata:
			try:
				type =  v[u'data'][u'type']
				if type == 'oci_compartment':
					response.append(v[u'data'][u'node_data'])
			except:
				continue
		response = (str(response)).replace ("u'","'")
 	else:
		try:
			config = from_file(profile_name=args['profile'])
		except ProfileNotFound:
			print( "Profile " + args['profile'] + " not found in config file")
			return ""
			exit()	
		

		

		identity = oci.identity.identity_client.IdentityClient(config)
		rootCompartmentId = config["tenancy"].strip()
				
		if (args['proxy'] != "false" and args['proxy'] != None):
			identity.base_client.session.proxies = { 'https': args['proxy'] }

		# get root compartment
		rc = identity.get_compartment(rootCompartmentId).data
		# get listof compartments
		compartments = identity.list_compartments(rootCompartmentId).data
		# add root compartment to list
		compartments.append(rc)
		response = str(compartments)
	if (args['callback'] != None):
		response = args['callback'] + "({'data': " + response + "})"
		
	return response

	
# get the list of avialable profiles in the oci config file	
@app.route('/profiles')
def getProfiles():

	home = expanduser("~")
	profiles = []
	configFile = os.path.join(home, ".oci","config")
#	print configFile
	file =  open(configFile, 'rb') 
	for line in file: 
		if line.startswith("[") :
			prof = line.replace('[','')
			prof = prof.replace(']\r\n','')
			profiles.append(prof)
	return json.dumps(profiles)
	
# get the list of VCNs in a given compartment
@app.route('/vcns')
def getVcns():
	profile = "DEFAULT"
	compId=None
	args = request.args
	for arg in args:
		if (arg == "profile"):
			profile = args[arg]
		elif (arg == "compId"):
			compId = args[arg]

	if compId == None:
		return "No Compartment Id was received"
	try:
		config = from_file(profile_name=profile)
		
	except ProfileNotFound:
		msg = "Profile " + profile + " not found in config file"
		return msg
		exit()	
	network = oci.core.virtual_network_client.VirtualNetworkClient(config)
	args = request.args
	if (args.proxy != None):
		network.base_client.session.proxies = { 'https': args.proxy }
	
	
	compVcns = network.list_vcns(compId).data

	return str(compartments)	
	
def parseArgs(args):

	myargs = {}
	myargs['mode'] = "REST"
	myargs['callback'] = None
	myargs['proxy'] = None
	myargs['profile'] = "DEFAULT"
	
	
	for arg in args:
		if (str(arg) == "profile"):
			myargs['profile'] = str(args[arg])
		if (str(arg) == "proxy"):
			myargs['proxy'] = str(args[arg])
		if (str(arg) == "callback"):
			myargs['callback'] = str(args[arg])
		if (str(arg) == "mode"):
			myargs['mode'] = str(args[arg])
			
	return myargs

			
